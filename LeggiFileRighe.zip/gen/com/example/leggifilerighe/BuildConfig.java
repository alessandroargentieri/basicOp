/** Automatically generated file. DO NOT MODIFY */
package com.example.leggifilerighe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}