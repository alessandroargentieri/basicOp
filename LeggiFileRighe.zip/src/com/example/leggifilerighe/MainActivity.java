package com.example.leggifilerighe;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import android.os.Bundle;
import android.os.Environment;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {

	@SuppressLint("SdCardPath")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		String[] riga = new String[10];
		for (int j =0; j<10;j++)
			riga[j] = "";
		
		try{
	          FileInputStream fstream = new FileInputStream("/sdcard/Percorso1.txt");
	          DataInputStream in = new DataInputStream(fstream);
	          BufferedReader br = new BufferedReader(new InputStreamReader(in));
	          String line = "";
	          int i = 0;
	          while ((line = br.readLine()) != null) {
	        	  riga[i] = line;
	        	  i = i+1;
	          }
	          in.close();
		}catch (Exception e){
			Toast.makeText(getBaseContext(), "Exception", Toast.LENGTH_LONG).show();
		}
	String[] profile = riga[5].split("\\|");
	Toast.makeText(getBaseContext(), profile[2], Toast.LENGTH_LONG).show();
	File roote = Environment.getExternalStorageDirectory();
    String Stringa = "ciao|questa\n� una prova|molto\ncarina|davvero";
	 try 
	    {
	    	BufferedWriter fw = new BufferedWriter(new FileWriter(new File("/sdcard/mitico.txt"), false));
	    	if (roote.canWrite()) 
	    	{
	           // fw.newLine();
	            fw.write("----+ JSON +----" + "\n");	
	            fw.write(Stringa);
	          //  fw.newLine();
	            fw.close();
	    	}	
	    }catch (IOException e) {
	    	Toast.makeText(getBaseContext(), "CIAO", Toast.LENGTH_LONG).show();
	    	}	
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
