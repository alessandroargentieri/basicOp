package com.example.findmacconnectbluetooth;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.DialogInterface.OnClickListener;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity {
	public String MAC_CLICKED = "";
	private BluetoothAdapter myBluetoothAdapter;
	private ListView myListView;
	private ArrayAdapter<String> BTArrayAdapter;
	private static final int REQUEST_ENABLE_BT = 1;
	public List<String> Names = new ArrayList<String>();
	public List<String> Macs = new ArrayList<String>();
	private BluetoothSocket btSocket = null;
	private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

	   
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		/* se non esiste il folder, creare il folder */
		File folder = new File(Environment.getExternalStorageDirectory() + "/Asiagem");
		boolean success = true;
		if (!folder.exists()) {
		    success = folder.mkdir();
		}
		myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if(myBluetoothAdapter == null) {
			Toast.makeText(getApplicationContext(),"Your device does not support Bluetooth", Toast.LENGTH_LONG).show();
		}else {
			if (!myBluetoothAdapter.isEnabled()) {
		         Intent turnOnIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		         startActivityForResult(turnOnIntent, REQUEST_ENABLE_BT);

		         Toast.makeText(getApplicationContext(),"Bluetooth turned on" ,
		        		 Toast.LENGTH_LONG).show();
		      }
		      else{
		         Toast.makeText(getApplicationContext(),"Bluetooth is already on",
		        		 Toast.LENGTH_LONG).show();
		      }
		}
		
		 myListView = (ListView)findViewById(R.id.listView1);
			
	      // create the arrayAdapter that contains the BTDevices, and set it to the ListView
	      BTArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
	      myListView.setAdapter(BTArrayAdapter);
	      myListView.setOnItemClickListener(new OnItemClickListener()
	      {
	  		@Override
	  		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			// TODO Auto-generated method stub
	  		//	Toast.makeText(getApplicationContext(),"Ciao" + arg2, Toast.LENGTH_LONG).show();
	  			MAC_CLICKED = Macs.get(arg2);
		    	Toast.makeText(getApplicationContext(), MAC_CLICKED + " pressed" , Toast.LENGTH_SHORT).show();
		    	// lo salva in un file testuale //
		    	File root_text = Environment.getExternalStorageDirectory();
				try{
					File folder = new File(Environment.getExternalStorageDirectory() + "/Asiagem");
					boolean success = true;
					if (!folder.exists()) {
						success = folder.mkdir();
					}
					BufferedWriter fwv = new BufferedWriter(new FileWriter(new File("/sdcard/Asiagem/MAC.txt"), false));
					if (root_text.canWrite()) {
						fwv.write(MAC_CLICKED);
						fwv.close();
					}
					connecting(MAC_CLICKED);
				}catch (Exception e){}
	  			
	  			
	  			
		}
	       });
		
		
		
		
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	   protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		   // TODO Auto-generated method stub
	//	findmac();
	   }
	
	
	
	public void find(View v) {
		findmac();
	}
	
	public void connect(View v) {
		
		//Toast.makeText(getApplicationContext(),"Connect pressed" , Toast.LENGTH_SHORT).show();
		/* legge da file il mac salvato */
		 try{
		    	String MACFile = readFileAsString("/sdcard/Asiagem/MAC.txt");
				if(MACFile==""){
					findmac();
				}else {
					connecting(MACFile);
				}
		 }catch(Exception e){
			 Toast.makeText(getApplicationContext(),"Errore nella lettura dei dati" , Toast.LENGTH_SHORT).show();
		 }
	}
	
	public void connecting(String mac){
		 Toast.makeText(getApplicationContext(),"Mac: " + mac , Toast.LENGTH_SHORT).show();
		 ///"""""""""""
		 
             BluetoothDevice device = myBluetoothAdapter.getRemoteDevice(mac);
             myBluetoothAdapter.cancelDiscovery();
             try {
                     btSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
                     btSocket.connect();
                     Toast.makeText(getApplicationContext(), "Connessione effettuata", Toast.LENGTH_SHORT).show();
             } catch (IOException e) {
                     try {
                             btSocket.close();
                     } catch (IOException e2) {
                             Toast.makeText(getApplicationContext(), "Impossibile terminare la connessione",Toast.LENGTH_SHORT).show();
                     }
                     Toast.makeText(getApplicationContext(), "Creazione socket fallita.", Toast.LENGTH_SHORT).show();
            }
            
            // beginListenForData();
     
		 
		 
		 
		 
		 ///"""""""""""
	}
	
	public void findmac(){  
		if (myBluetoothAdapter.isDiscovering()) {
			   // the button is pressed when it discovers, so cancel the discovery
			   myBluetoothAdapter.cancelDiscovery();
		   }
		   else {
				BTArrayAdapter.clear();
				Names.clear();
				Macs.clear();
				try{
					myBluetoothAdapter.startDiscovery();
					registerReceiver(bReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));	
				}catch(Exception e){Toast.makeText(getApplicationContext(), e.toString() , Toast.LENGTH_SHORT).show(); }
			}  
		
			   
	}
	
	public static String readFileAsString(String filePath) {

	    String result = "";
	    File file = new File(filePath);
	    if ( file.exists() ) {
	       FileInputStream fis = null;
	        try {
	           fis = new FileInputStream(file);
	            char current;
	            while (fis.available() > 0) {
	                current = (char) fis.read();
	                result = result + String.valueOf(current);

	            }

	        } catch (Exception e) {
	            Log.d("ERRORE", e.toString());
	        } finally {
	            if (fis != null)
	                try {
	                    fis.close();
	                } catch (IOException ignored) {
	            }
	        }
	       
	   }
	    return result;
	    }
	
	
	final BroadcastReceiver bReceiver = new BroadcastReceiver() {
	    public void onReceive(Context context, Intent intent) {
	        String action = intent.getAction();
	        // When discovery finds a device
	        if (BluetoothDevice.ACTION_FOUND.equals(action)) {
	             // Get the BluetoothDevice object from the Intent
	        	 BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
	        	 // add the name and the MAC address of the object to the arrayAdapter
	             BTArrayAdapter.add(device.getName() + "\n" + device.getAddress());
	             BTArrayAdapter.notifyDataSetChanged();
	              String nome = device.getName();
	              String mac = device.getAddress();
	              Log.e("CIAO", nome + " " + mac);
	             Names.add(nome);
	             Macs.add(mac);
	           
	             
	        }
	    }
	};
	

	

}
